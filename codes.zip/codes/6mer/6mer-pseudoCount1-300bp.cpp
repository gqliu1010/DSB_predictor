

#include "string.h"
#include "math.h"
#include"stdio.h"
#include "stdlib.h"
#include"ctype.h"
#include"conio.h"

int tag[100]={0};



void main1()
{

	FILE *fp1; FILE *fp2; FILE *fp3; FILE *fp4;


	static double oner1[4], twoer1[4][4], trimer1[4][4][4], former1[4][4][4][4], fiver1[4][4][4][4][4], sixer1[4][4][4][4][4][4];
	static double sevener1[4][4][4][4][4][4][4], eighter1[4][4][4][4][4][4][4][4];

	static double P1[4], P2[4][4], P3[4][4][4], P4[4][4][4][4], P5[4][4][4][4][4], P6[4][4][4][4][4][4];
	static double P7[4][4][4][4][4][4][4], P8[4][4][4][4][4][4][4][4];

	static double Q1[4], Q2[4][4], Q3[4][4][4], Q4[4][4][4][4], Q5[4][4][4][4][4], Q6[4][4][4][4][4][4];
	static double Q7[4][4][4][4][4][4][4], Q8[4][4][4][4][4][4][4][4];

	static double R1[4], R2[4][4], R3[4][4][4], R4[4][4][4][4], R5[4][4][4][4][4], R6[4][4][4][4][4][4];
	static double R7[4][4][4][4][4][4][4], R8[4][4][4][4][4][4][4][4];

	double sum[9], sum1[9], pos,lamda=1;
	char str[1000004];
	char ch[4] = { 'A', 'T', 'G', 'C' };
	long int i, j, k, l, m, p, q, r, s, t;
	long int n1 = 0;



	long int window = 500000;


	fp1 = fopen("DSB_positive_1000bp.fa", "r");
	fp2 = fopen("DSB_negative_1000bp.fa", "r");


	if ((fp3 = fopen("DSB_pos1000bp_6mer.txt", "w+")) == NULL)
	{
		printf("cannot open this file \n");
		exit(0);
	}

	if ((fp4 = fopen("DSB_neg1000bp_6mer.txt", "w+")) == NULL)
	{
		printf("cannot open this file \n");
		exit(0);
	}




	for (i = 0; i<4; i++)
	{
		for (j = 0; j<4; j++)
		{
			for (k = 0; k<4; k++)
			{
				for (l = 0; l<4; l++)
				{
					for (p = 0; p<4; p++)
					{
						
						for (q = 0; q<4; q++)
						{
							if(i==0&&j==0&&k==0&&l==0&&p==0&&q==0) 
							{
								fprintf(fp3,"%c%c%c%c%c%c",ch[i],ch[j],ch[k],ch[l],ch[p],ch[q]);
								fprintf(fp4,"%c%c%c%c%c%c",ch[i],ch[j],ch[k],ch[l],ch[p],ch[q]);
							}
							else
							{
								fprintf(fp3,"\t%c%c%c%c%c%c",ch[i],ch[j],ch[k],ch[l],ch[p],ch[q]);
								fprintf(fp4,"\t%c%c%c%c%c%c",ch[i],ch[j],ch[k],ch[l],ch[p],ch[q]);
							}
							for (r = 0; r<4; r++)
							{
								for (s = 0; s<4; s++)
								{
								}
							}
						}
					}
				}
			}
		}
	}
	fprintf(fp3,"\n");
	fprintf(fp4,"\n");

	for (t = 1; t<2; t++)
	{

		fgets(str, window, fp1);
		do
		{
			if (feof(fp1))
				break;
			if (str[0] == '>')
			{

				///////////����ֵ////////
				for (i = 0; i < 4; i++)
				{
					oner1[i] = 0;
					for (j = 0; j < 4; j++)
					{
						twoer1[i][j] = 0;
						for (k = 0; k < 4; k++)
						{
							trimer1[i][j][k] = 0;
							for (l = 0; l < 4; l++)
							{
								former1[i][j][k][l] = 0;
								for (p = 0; p < 4; p++)
								{
									fiver1[i][j][k][l][p] = 0;
									for (q = 0; q < 4; q++)
									{
										sixer1[i][j][k][l][p][q] = 0;
										for (r = 0; r < 4; r++)
										{
											sevener1[i][j][k][l][p][q][r] = 0;
											for (s = 0; s < 4; s++)
											{
												eighter1[i][j][k][l][p][q][r][s] = 0;
											}
										}
									}
								}
							}
						}
					}
				}


				for (i = 0; i < 9; i++)
					sum1[i] = 0;

				memset(str, '\0', window);
				fgets(str, window, fp1);

				continue;
			}

			while (str[0] != '>')
			{
				if (feof(fp1))
					break;
				for (m = 0; m<window; m++)
				{
					if (str[m] == '\0')
						break;
					for (i = 0; i<4; i++)
					if (str[m] == ch[i])
					{
						oner1[i] = oner1[i] + 1;
						for (j = 0; j<4; j++)
						if (str[m + 1] == ch[j])
						{
							twoer1[i][j] = twoer1[i][j] + 1;
							for (k = 0; k<4; k++)
							if (str[m + 2] == ch[k])
							{
								trimer1[i][j][k] = trimer1[i][j][k] + 1;
								for (l = 0; l<4; l++)
								if (str[m + 3] == ch[l])
								{
									former1[i][j][k][l] = former1[i][j][k][l] + 1;
									for (p = 0; p<4; p++)
									if (str[m + 4] == ch[p])
									{
										fiver1[i][j][k][l][p] = fiver1[i][j][k][l][p] + 1;
										for (q = 0; q<4; q++)
										if (str[m + 5] == ch[q])
										{
											sixer1[i][j][k][l][p][q] = sixer1[i][j][k][l][p][q] + 1;
											for (r = 0; r<4; r++)
											if (str[m + 6] == ch[r])
											{
												sevener1[i][j][k][l][p][q][r] = sevener1[i][j][k][l][p][q][r] + 1;
												for (s = 0; s<4; s++)
												if (str[m + 7] == ch[s])
												{
													eighter1[i][j][k][l][p][q][r][s] = eighter1[i][j][k][l][p][q][r][s] + 1;
												}
											}
										}
									}
								}
							}
						}
					}
				}
				memset(str, '\0', window);
				fgets(str, window, fp1);

			}





			for (i = 0; i<4; i++)
			{
				sum1[1] = sum1[1] + oner1[i];
				for (j = 0; j<4; j++)
				{
					sum1[2] = sum1[2] + twoer1[i][j];
					for (k = 0; k<4; k++)
					{
						sum1[3] = sum1[3] + trimer1[i][j][k];
						for (l = 0; l<4; l++)
						{
							sum1[4] = sum1[4] + former1[i][j][k][l];
							for (p = 0; p<4; p++)
							{
								sum1[5] = sum1[5] + fiver1[i][j][k][l][p];
								for (q = 0; q<4; q++)
								{
									sum1[6] = sum1[6] + sixer1[i][j][k][l][p][q];
									for (r = 0; r<4; r++)
									{
										sum1[7] = sum1[7] + sevener1[i][j][k][l][p][q][r];
										for (s = 0; s<4; s++)
										{
											sum1[8] = sum1[8] + eighter1[i][j][k][l][p][q][r][s];

										}
									}
								}
							}
						}
					}
				}
			}








			for (i = 0; i<4; i++)
			{
				P1[i] = (oner1[i]+lamda) / (sum1[1]+4*lamda);
				for (j = 0; j<4; j++)
				{
					P2[i][j] = (twoer1[i][j]+lamda) / (sum1[2]+4*4*lamda);
					for (k = 0; k<4; k++)
					{
						P3[i][j][k] = (trimer1[i][j][k]+lamda) / (sum1[3]+4*4*4*lamda);
						for (l = 0; l<4; l++)
						{
							P4[i][j][k][l] = (former1[i][j][k][l]+lamda) / (sum1[4]+4*4*4*4*lamda);
							for (p = 0; p<4; p++)
							{
								P5[i][j][k][l][p] = (fiver1[i][j][k][l][p]+lamda) / (sum1[5]+4*4*4*4*4*lamda);
								for (q = 0; q<4; q++)
								{
									P6[i][j][k][l][p][q] = (sixer1[i][j][k][l][p][q]+lamda) / (sum1[6]+4*4*4*4*4*4*lamda);
									for (r = 0; r<4; r++)
									{
										P7[i][j][k][l][p][q][r] = (sevener1[i][j][k][l][p][q][r]+lamda) / (sum1[7]+4*4*4*4*4*4*4*lamda);
										for (s = 0; s<4; s++)
										{
											P8[i][j][k][l][p][q][r][s] = (eighter1[i][j][k][l][p][q][r][s]+lamda) / (sum1[8]+4*4*4*4*4*4*4*4*lamda);
										}
									}
								}
							}
						}
					}
				}
			}




			for (i = 0; i<4; i++)
			{

				for (j = 0; j<4; j++)
				{
					Q2[i][j] = P1[i] * P1[j];
					for (k = 0; k<4; k++)
					{
						Q3[i][j][k] = P2[i][j] * P2[j][k] / P1[j];
						for (l = 0; l<4; l++)
						{
							Q4[i][j][k][l] = P3[i][j][k] * P3[j][k][l] / P2[j][k];
							if (P2[j][k] == 0)
								Q4[i][j][k][l] = 0;
							for (p = 0; p<4; p++)
							{
								Q5[i][j][k][l][p] = P4[i][j][k][l] * P4[j][k][l][p] / P3[j][k][l];
								for (q = 0; q<4; q++)
								{
									Q6[i][j][k][l][p][q] = P5[i][j][k][l][p] * P5[j][k][l][p][q] / P4[j][k][l][p];
									for (r = 0; r<4; r++)
									{
										Q7[i][j][k][l][p][q][r] = P6[i][j][k][l][p][q] * P6[j][k][l][p][q][r] / P5[j][k][l][p][q];
										for (s = 0; s<4; s++)
										{
											Q8[i][j][k][l][p][q][r][s] = P7[i][j][k][l][p][q][r] * P7[j][k][l][p][q][r][s] / P6[j][k][l][p][q][r];

										}
									}
								}
							}
						}
					}
				}
			}





			for (i = 0; i < 4; i++)
			{

				for (j = 0; j < 4; j++)
				{
					R2[i][j] = (P2[i][j] - Q2[i][j]) / Q2[i][j];
					for (k = 0; k < 4; k++)
					{
						R3[i][j][k] = (P3[i][j][k] - Q3[i][j][k]) / Q3[i][j][k];
						for (l = 0; l < 4; l++)
						{
							R4[i][j][k][l] = (P4[i][j][k][l] - Q4[i][j][k][l]) / Q4[i][j][k][l];
							if (Q4[i][j][k][l]  == 0)
								R4[i][j][k][l]= 0;
							for (p = 0; p < 4; p++)
							{
								R5[i][j][k][l][p] = (P5[i][j][k][l][p] - Q5[i][j][k][l][p]) / Q5[i][j][k][l][p];
								for (q = 0; q < 4; q++)
								{
									R6[i][j][k][l][p][q] = (P6[i][j][k][l][p][q] - Q6[i][j][k][l][p][q]) / Q6[i][j][k][l][p][q];
									for (r = 0; r < 4; r++)
									{
										R7[i][j][k][l][p][q][r] = (P7[i][j][k][l][p][q][r] - Q7[i][j][k][l][p][q][r]) / Q7[i][j][k][l][p][q][r];
										for (s = 0; s < 4; s++)
										{
											R8[i][j][k][l][p][q][r][s] = (P8[i][j][k][l][p][q][r][s] - Q8[i][j][k][l][p][q][r][s]) / Q8[i][j][k][l][p][q][r][s];
										}
									}
								}
							}
						}
					}
				}
			}




			n1++;

			//fprintf(fp4, "%d\t", n1);

			//printf("%d\n", n1);

			//fprintf(fp3, "yes\t");
			printf("hot set1\n");





			for (i = 0; i < 4; i++)
			{
				//fprintf(fp3,"\t%f",R1[i]);
				for (j = 0; j < 4; j++)
				{
					//fprintf(fp3,"\t%f",R2[i][j]);
					for (k = 0; k < 4; k++)
					{
						//fprintf(fp3,"\t%f",R3[i][j][k]);
						for (l = 0; l < 4; l++)
						{
							//fprintf(fp3, "%f\t", R4[i][j][k][l]);
							for (p = 0; p < 4; p++)
							{
								//fprintf(fp3,"\t%f",R5[i][j][k][l][p]);
								for (q = 0; q < 4; q++)
								{
									if(i==0&&j==0&&k==0&&l==0&&p==0&&q==0) 
										fprintf(fp3,"%f",P6[i][j][k][l][p][q]);
									else
										fprintf(fp3,"\t%f",P6[i][j][k][l][p][q]);
									for (r = 0; r < 4; r++)
									{
										//fprintf(fp3,"\t%f",R7[i][j][k][l][p][q][r]);
										for (s = 0; s < 4; s++)
										{
											//fprintf(fp3,"\t%f",R8[i][j][k][l][p][q][r][s]);
										}
									}
								}
							}
						}
					}
				}
			}

			fprintf(fp3, "\n");





		} while (!feof(fp1));

	//end:
		fclose(fp1);

		n1 = 0;
	}
	fclose(fp1);
	fclose(fp3);




	

	for (t = 1; t<2; t++)
	{


		fgets(str, window, fp2);
		do
		{
			if (feof(fp2))
				break;
			if (str[0] == '>')
			{

				///////////����ֵ////////
				for (i = 0; i < 4; i++)
				{
					oner1[i] = 0;
					for (j = 0; j < 4; j++)
					{
						twoer1[i][j] = 0;
						for (k = 0; k < 4; k++)
						{
							trimer1[i][j][k] = 0;
							for (l = 0; l < 4; l++)
							{
								former1[i][j][k][l] = 0;
								for (p = 0; p < 4; p++)
								{
									fiver1[i][j][k][l][p] = 0;
									for (q = 0; q < 4; q++)
									{
										sixer1[i][j][k][l][p][q] = 0;
										for (r = 0; r < 4; r++)
										{
											sevener1[i][j][k][l][p][q][r] = 0;
											for (s = 0; s < 4; s++)
											{
												eighter1[i][j][k][l][p][q][r][s] = 0;
											}
										}
									}
								}
							}
						}
					}
				}


				for (i = 0; i < 9; i++)
					sum1[i] = 0;

				memset(str, '\0', window);
				fgets(str, window, fp2);

				continue;
			}

			while (str[0] != '>')
			{
				if (feof(fp2))
					break;
				for (m = 0; m<window; m++)
				{
					if (str[m] == '\0')
						break;
					for (i = 0; i<4; i++)
					if (str[m] == ch[i])
					{
						oner1[i] = oner1[i] + 1;
						for (j = 0; j<4; j++)
						if (str[m + 1] == ch[j])
						{
							twoer1[i][j] = twoer1[i][j] + 1;
							for (k = 0; k<4; k++)
							if (str[m + 2] == ch[k])
							{
								trimer1[i][j][k] = trimer1[i][j][k] + 1;
								for (l = 0; l<4; l++)
								if (str[m + 3] == ch[l])
								{
									former1[i][j][k][l] = former1[i][j][k][l] + 1;
									for (p = 0; p<4; p++)
									if (str[m + 4] == ch[p])
									{
										fiver1[i][j][k][l][p] = fiver1[i][j][k][l][p] + 1;
										for (q = 0; q<4; q++)
										if (str[m + 5] == ch[q])
										{
											sixer1[i][j][k][l][p][q] = sixer1[i][j][k][l][p][q] + 1;
											for (r = 0; r<4; r++)
											if (str[m + 6] == ch[r])
											{
												sevener1[i][j][k][l][p][q][r] = sevener1[i][j][k][l][p][q][r] + 1;
												for (s = 0; s<4; s++)
												if (str[m + 7] == ch[s])
												{
													eighter1[i][j][k][l][p][q][r][s] = eighter1[i][j][k][l][p][q][r][s] + 1;
												}
											}
										}
									}
								}
							}
						}
					}
				}
				memset(str, '\0', window);
				fgets(str, window, fp2);

			}





			for (i = 0; i<4; i++)
			{
				sum1[1] = sum1[1] + oner1[i];
				for (j = 0; j<4; j++)
				{
					sum1[2] = sum1[2] + twoer1[i][j];
					for (k = 0; k<4; k++)
					{
						sum1[3] = sum1[3] + trimer1[i][j][k];
						for (l = 0; l<4; l++)
						{
							sum1[4] = sum1[4] + former1[i][j][k][l];
							for (p = 0; p<4; p++)
							{
								sum1[5] = sum1[5] + fiver1[i][j][k][l][p];
								for (q = 0; q<4; q++)
								{
									sum1[6] = sum1[6] + sixer1[i][j][k][l][p][q];
									for (r = 0; r<4; r++)
									{
										sum1[7] = sum1[7] + sevener1[i][j][k][l][p][q][r];
										for (s = 0; s<4; s++)
										{
											sum1[8] = sum1[8] + eighter1[i][j][k][l][p][q][r][s];

										}
									}
								}
							}
						}
					}
				}
			}









			for (i = 0; i<4; i++)
			{
				P1[i] = (oner1[i]+lamda) / (sum1[1]+4*lamda);
				for (j = 0; j<4; j++)
				{
					P2[i][j] = (twoer1[i][j]+lamda) / (sum1[2]+4*4*lamda);
					for (k = 0; k<4; k++)
					{
						P3[i][j][k] = (trimer1[i][j][k]+lamda) / (sum1[3]+4*4*4*lamda);
						for (l = 0; l<4; l++)
						{
							P4[i][j][k][l] = (former1[i][j][k][l]+lamda) / (sum1[4]+4*4*4*4*lamda);
							for (p = 0; p<4; p++)
							{
								P5[i][j][k][l][p] = (fiver1[i][j][k][l][p]+lamda) / (sum1[5]+4*4*4*4*4*lamda);
								for (q = 0; q<4; q++)
								{
									P6[i][j][k][l][p][q] = (sixer1[i][j][k][l][p][q]+lamda) / (sum1[6]+4*4*4*4*4*4*lamda);
									for (r = 0; r<4; r++)
									{
										P7[i][j][k][l][p][q][r] = (sevener1[i][j][k][l][p][q][r]+lamda) / (sum1[7]+4*4*4*4*4*4*4*lamda);
										for (s = 0; s<4; s++)
										{
											P8[i][j][k][l][p][q][r][s] = (eighter1[i][j][k][l][p][q][r][s]+lamda) / (sum1[8]+4*4*4*4*4*4*4*4*lamda);
										}
									}
								}
							}
						}
					}
				}
			}





			for (i = 0; i<4; i++)
			{

				for (j = 0; j<4; j++)
				{
					Q2[i][j] = P1[i] * P1[j];
					for (k = 0; k<4; k++)
					{
						Q3[i][j][k] = P2[i][j] * P2[j][k] / P1[j];
						for (l = 0; l<4; l++)
						{
							Q4[i][j][k][l] = P3[i][j][k] * P3[j][k][l] / P2[j][k];
							if (P2[j][k] == 0)
								Q4[i][j][k][l] = 0;
							for (p = 0; p<4; p++)
							{
								Q5[i][j][k][l][p] = P4[i][j][k][l] * P4[j][k][l][p] / P3[j][k][l];
								for (q = 0; q<4; q++)
								{
									Q6[i][j][k][l][p][q] = P5[i][j][k][l][p] * P5[j][k][l][p][q] / P4[j][k][l][p];
									for (r = 0; r<4; r++)
									{
										Q7[i][j][k][l][p][q][r] = P6[i][j][k][l][p][q] * P6[j][k][l][p][q][r] / P5[j][k][l][p][q];
										for (s = 0; s<4; s++)
										{
											Q8[i][j][k][l][p][q][r][s] = P7[i][j][k][l][p][q][r] * P7[j][k][l][p][q][r][s] / P6[j][k][l][p][q][r];

										}
									}
								}
							}
						}
					}
				}
			}





			for (i = 0; i < 4; i++)
			{

				for (j = 0; j < 4; j++)
				{
					R2[i][j] = (P2[i][j] - Q2[i][j]) / Q2[i][j];
					for (k = 0; k < 4; k++)
					{
						R3[i][j][k] = (P3[i][j][k] - Q3[i][j][k]) / Q3[i][j][k];
						for (l = 0; l < 4; l++)
						{
							R4[i][j][k][l] = (P4[i][j][k][l] - Q4[i][j][k][l]) / Q4[i][j][k][l];
							if (Q4[i][j][k][l] == 0)
								R4[i][j][k][l] = 0;
							for (p = 0; p < 4; p++)
							{
								R5[i][j][k][l][p] = (P5[i][j][k][l][p] - Q5[i][j][k][l][p]) / Q5[i][j][k][l][p];
								for (q = 0; q < 4; q++)
								{
									R6[i][j][k][l][p][q] = (P6[i][j][k][l][p][q] - Q6[i][j][k][l][p][q]) / Q6[i][j][k][l][p][q];
									for (r = 0; r < 4; r++)
									{
										R7[i][j][k][l][p][q][r] = (P7[i][j][k][l][p][q][r] - Q7[i][j][k][l][p][q][r]) / Q7[i][j][k][l][p][q][r];
										for (s = 0; s < 4; s++)
										{
											R8[i][j][k][l][p][q][r][s] = (P8[i][j][k][l][p][q][r][s] - Q8[i][j][k][l][p][q][r][s]) / Q8[i][j][k][l][p][q][r][s];
										}
									}
								}
							}
						}
					}
				}
			}




			n1++;

			//fprintf(fp4, "%d\t", n1);

			//printf("%d\n", n1);

			//fprintf(fp4, "no\t");
			printf("cold set1\n");





			for (i = 0; i < 4; i++)
			{
				//fprintf(fp4,"\t%f",R1[i]);
				for (j = 0; j < 4; j++)
				{
					//fprintf(fp4,"\t%f",R2[i][j]);
					for (k = 0; k < 4; k++)
					{
						//fprintf(fp4,"\t%f",R3[i][j][k]);
						for (l = 0; l < 4; l++)
						{
							//fprintf(fp4, "%f\t", R4[i][j][k][l]);
							for (p = 0; p < 4; p++)
							{
								//fprintf(fp4,"\t%f",R5[i][j][k][l][p]);
								for (q = 0; q < 4; q++)
								{
									if(i==0&&j==0&&k==0&&l==0&&p==0&&q==0) 
										fprintf(fp4,"%f",P6[i][j][k][l][p][q]);
									else
										fprintf(fp4,"\t%f",P6[i][j][k][l][p][q]);
									for (r = 0; r < 4; r++)
									{
										//fprintf(fp4,"\t%f",R7[i][j][k][l][p][q][r]);
										for (s = 0; s < 4; s++)
										{
											//fprintf(fp4,"\t%f",R8[i][j][k][l][p][q][r][s]);
										}
									}
								}
							}
						}
					}
				}
			}

			fprintf(fp4, "\n");





		} while (!feof(fp2));

	//end:
		fclose(fp2);

		n1 = 0;
	}

	//fprintf(fp4, "#");
	fclose(fp2);
	fclose(fp4);

}





int main()
{
	main1();
}

// ConsoleApplication1.cpp : �������̨Ӧ�ó������ڵ㡣
//



#include "string.h"
#include "math.h"
#include"stdio.h"
#include "stdlib.h"
#include"ctype.h"
#include"conio.h"



int main()
{
	FILE*fp1, *fp2, *fout[20];
	long int i, j, k, l, m, n, p, N1,N2, t = 0, num=0,count = 0;
	char str[50001], head[100], step[4], enter[] = "\n", ww[100];
	double lichangshu[4][18];
	long int oner[4],  length, window1 = 5000, window2 = 11, half;
	double gc, sum1, sum2;
	double sum[18], G[18];
	char ch[4] = { 'A', 'G', 'C', 'T' };
	char filename1[1000], filename2[] = "chemicalshift_negdata_", filename3[100], filename4[] = ".txt";



	if ((fp1 = fopen("chemicalshift.txt", "r")) == NULL)
	{
		printf("cannot open this file1 \n");
		exit(0);
	}



	if ((fp2 = fopen("D:\\�ṹ����ѧ\\DSB GC and information\\DSB_negative_1000bp.fa", "r")) == NULL)
	{
		printf("cannot open fp1 \n");
		exit(0);
	}
	


	for (i = 0; i < 18; i++)
	{

		for (j = 0; j < 100; j++)
		{
			filename1[j] = '\0';
		}

		_itoa(i + 1, filename3, 10);
		strcpy(filename1, filename2);
		strcat(filename1, filename3);
		strcat(filename1, filename4);


		if ((fout[i] = fopen(filename1, "w+")) == NULL)
		{
			printf("cannot open this file \n");
			exit(0);
		}
	}




	for (m = 0; m< 19; m++)
	{
		fscanf(fp1, "%s,\t", &head);
	}


	for (m = 0; m< 4; m++)               ///     'm�����������������
	{
		fscanf(fp1, "%s\t", &step);
		printf("%s\t", step);
		for (n = 0; n< 18; n++)            ///     'n�����������������
		{
			fscanf(fp1, "%lf\t", &lichangshu[m][n]);
			printf("%lf\t", lichangshu[m][n]);
		}
		printf("\n");
	}







	count = 0;

	while (!feof(fp2))
	{
		memset(str, '\0', window1);
		fgets(str, window1 + 1, fp2);




		if (str[0] == '>')
		{
				
			count++;
			printf("%s",str);
	
			//for (i = 0; i < 15; i++)
			//	fprintf(fout[i],"seq%d",count);
	
			continue;
		}
		
		

		length = strlen(str);
		
		
		
		if(length==0)
			break;
			
			
			
		///if (str[window - 1] == '\n')
		if(strstr(str,enter)!=NULL)
		{
			for (i = 0; i < 18; i++)
				fprintf(fout[i],"\n");
		}




		///////////////////////////////////������ͳ�Ƽ������////////////////////				
		sum1 = 0;
		for (i = 0; i<4; i++)
			oner[i] = 0;


		for (l = 0; l<window1; l++)
		{
			if (str[l] == '\n')
				break;
			for (j = 0; j<4; j++)
			if (str[l] == ch[j])
				oner[j] = oner[j] + 1;
		}


		for (i = 0; i<4; i++)
			sum1 = sum1 + oner[i];

		gc = (oner[2] + oner[3]) / sum1;


		//f1[0]=f1[1]=(oner[0]+oner[1])*0.5;
		//f1[2]=f1[3]=(oner[2]+oner[3])*0.5;




		////////////////////////////////////ͳ��2-mer///////////////////////////



		for (n = 0; n < 18; n++)
			sum[n] = 0;

	

		for (l = 0; l<window1; l++)
		{
			if (str[l] == '\n')
			{
				///fprintf(fp4,"here:%c=%ld",str[l],l);////����Ƿ����쳣����///
				break;
			}

			for (j = 0; j < 4; j++)
			{
				if (str[l] == ch[j])
				{
					//oner[j] = oner[j] + 1;
					for (n = 0; n < 18; n++)
					{
						//printf( "%f", lichangshu[j][n]);
						if(l==0)
							fprintf(fout[n], "%f", lichangshu[j][n]);
						else
							fprintf(fout[n], "\t%f", lichangshu[j][n]);
					}	
					//sum[n] = sum[n] + lichangshu[j][n];

				}
			}
		}
	}


/*


		for (n = 0; n < 13; n++)
		{
			G[n] = sum[n] / sum1;
		}

		//printf("%f\n", G[2]);
		/////////////////////////////////////////////////////////////////////////////////////////



		for (n = 0; n < 13; n++)
		{
			if(num==1)
				fprintf(fout[n], "%f", G[n]);
			else
				fprintf(fout[n], "\t%f", G[n]);
		}

	}
	*/


	_fcloseall;

}


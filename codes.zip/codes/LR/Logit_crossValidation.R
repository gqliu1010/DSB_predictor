Logit<-function(){
  
  library(ROCR)
  #install.packages('e1071')
  #install.packages('caret')
  #library(caret) #confusionMatrix
  library(pROC) #绘制ROC曲线
  library(e1071)
  #library(openxlsx)
  
  
  library(tidyr)
  #library(corrplot)
  
  #install.packages('tidyr')
  
  rm(list=ls())
  data1=read.table("/home/DBY/DSB_result/DNAfeature_total_pos.txt",header =T,sep='\t',stringsAsFactors=F, comment.char = "!")
  data2=read.table("/home/DBY/DSB_result/DNAfeature_total_neg.txt",header =T,sep='\t',stringsAsFactors=F, comment.char = "!")
  
  #feature data里加label
  data1$tag=rep(1,nrow(data1))
  data2$tag=rep(0,nrow(data2))
  
  colnames(data2)=colnames(data1)
  
  data=rbind(data1,data2)
  ##########################################################################################
  set.seed(2)
  M=5 #M-fold cross validation
  fraction=1/5;
  ind<-sample(M,nrow(data),replace = T,prob = c(rep(fraction,M)))
  featureSet=1:ncol(data)
  
  ALLprob_values=NULL
  ALLpretag=NULL
  ALLtag=NULL
  sum_SE=0
  sum_SP=0
  sum_ACC=0
  sum_F=0
  #循环M次，分别取出第i部分作为测试样本，其余部分作为训练样本
  for(i in 1:M){
    pre_tag=NULL
    #将数据集分为训练集和测试集
    test_data<-data[ind==i,featureSet]
    train_data<-data[ind!=i,featureSet]
    
    #label为样本类别标签，同样选取相应的训练集对应的label(即从所有的label中选取train对应的label
    test_label=data$tag[ind==i]
    train_label=data$tag[ind!=i]
    
    
    ###计数测试集里的positive and negative data number###########
    posN=nrow(test_data[test_data$tag==1,])
    negN=nrow(test_data[test_data$tag==0,])
    ###计数训练集里的positive and negative data number###########
    posN1=nrow(train_data[train_data$tag==1,])
    negN1=nrow(train_data[train_data$tag==0,])
    
    #########################################################
    ##提取最后一列label以外的feature matrix
    train=train_data[,-ncol(train_data)]   
    test=test_data[,-ncol(test_data)]
    
    
    ###########用train data建立logistic回归模型#######################
    lm=glm(tag~.,data=train_data,family="binomial")  
    #family="binomial"用于logistic回归
    #lmstep=step(lm,direction="both")
    #通过逐步回归，筛选变量
    #summary(lmstep)
    
    ###########用逐步回归前后的logistic模型预测test set#################
    prob_values=predict(lm,test_data,type="response")  #response返回所属类别的概率,in the range of 0-1
    #For a default binomial model (logit model) the default predictions are of log-odds (probabilities on logit scale) and type = "response" gives the predicted probabilities.
    pre_tag1=as.factor(ifelse(prob_values>0.5,1,0))
    #prob_values_step=predict(lmstep,test_data,type="response")
    #pre_tag2=as.factor(ifelse(prob_values_step>0.5,1,0))
    
    pre_tag=pre_tag1
    ALLprob_values=c(ALLprob_values,prob_values)
    ALLpretag=c(ALLpretag,pre_tag)
    ALLtag=c(ALLtag,test_data$tag)
    #########################预测性能评估###########################
    CM.table=table(test_data$tag,pre_tag1,dnn=c("experiment","prediction"))
    # dnn=dimnames names;  CM.table  means confusion matrix
    AC1=sum(diag(CM.table))/sum(CM.table)
    #CM.table=table(test_data$tag,pre_tag2,dnn=c("experiment","prediction")) 
    #AC2=sum(diag(CM.table))/sum(CM.table)
    ##the results show that step regression model achieves almost the same level of accuracy using 20 features, instead of 34 features
    
    # TP <-  CM.table[2,2]
    # FP <- CM.table[1,2]
    # TN <- CM.table[1,1]
    # FN <- CM.table[2,1]
    
    TP <- length(test_data$tag[as.numeric(test_data$tag)==1 & pre_tag1==1])
    FP <- length(test_data$tag[as.numeric(test_data$tag)==0 & pre_tag1==1])
    TN <- length(test_data$tag[as.numeric(test_data$tag)==0 & pre_tag1==0])
    FN <- length(test_data$tag[as.numeric(test_data$tag)==1 & pre_tag1==0])
    ###########################################
    # 根据混淆矩阵计算特异度、敏感度以及准确度指标
    SE <- TP / (TP + FN)
    SP <- TN / (TN + FP)
    ACC <- (TP + TN) / (TP + TN + FP + FN)
    TPR<-SE
    TNR<-SP
    
    alpha=0.5
    PPV=TP/(TP+FP)   #positive predictive value, also called precision
    Fmeasure = 1/ (alpha*1/PPV + (1-alpha)*1/TPR)
    
    
    sum_SE=sum_SE+SE
    sum_SP=sum_SP+SP
    sum_ACC=sum_ACC+ACC
    sum_F=sum_F+Fmeasure
    
  }
  
  averSE=sum_SE/M
  averSP=sum_SP/M
  averACC=sum_ACC/M
  averF=sum_F/M
  
  Result=c(averSE,averSP,averACC,averF)
  write.table(Result,"logit_finalResult_averagePrediction.txt",quote=FALSE,col.names=T,row.names=F,sep='\t')
  
  
  ######################绘制整合全部prob values后的ROC曲线################################################
  Logit_roc <- roc(ALLtag,as.numeric(ALLprob_values))
  plot(Logit_roc,legacy.axes=T, print.auc=T, auc.polygon=T, grid=c(0.1, 0.1),grid.col=c("green", "red"), max.auc.polygon=T,auc.polygon.col="orange", print.thres=T,main='ROC curve, kernel = radial')
  #jpeg("ROC.jpeg",width=600*6,height=400*6,res=72*8)
  pdf("Logit_ROC_integratedPrediction.pdf",width=6,height=5)
  #par(mfcol=c(1,1))
  par(cex=1.3)
  #par(mar=c(4,4,2,1))
  #par(mgp = c(2, 0.5, 0))
  plot(Logit_roc,legacy.axes=T,print.auc=T, auc.polygon=T, max.auc.polygon=T,auc.polygon.col="orange", print.thres=F,print.thres.cex=1,print.auc.cex=1)
  dev.off()
  

  
  ################# 获取整合全部prob values后计算评价指标###########
  CM.table=table(ALLtag,ALLpretag,dnn=c("experiment","prediction"))
  TP <-  CM.table[2,2]
  FP <- CM.table[1,2]
  TN <- CM.table[1,1]
  FN <- CM.table[2,1]
  # ######计算在最佳阈值下混淆矩阵各项的值,与上面的结果一样############
  # cutoff=0.5
  # TP <- length(ALLtag[as.numeric(as.character(ALLtag))==1 & ALLprob_values > cutoff])
  # FP <- length(ALLtag[as.numeric(as.character(ALLtag))==0 & ALLprob_values > cutoff])
  # TN <- length(ALLtag[as.numeric(as.character(ALLtag))==0 & ALLprob_values <= cutoff])
  # FN <- length(ALLtag[as.numeric(as.character(ALLtag))==1 & ALLprob_values <= cutoff])
  
  # 根据混淆矩阵计算特异度、敏感度以及准确度指标
  SE <- TP / (TP + FN)
  SP <- TN / (TN + FP)
  ACC <- (TP + TN) / (TP + TN + FP + FN)
  TPR<-SE
  TNR<-SP
  
  alpha=0.5
  PPV=TP/(TP+FP)   #positive predictive value, also called precision
  Fmeasure = 1/ (alpha*1/PPV + (1-alpha)*1/TPR)
  
  Result=c(SE,SP,ACC,Fmeasure)
  write.table(Result,"Logit_finalResult_integratedPrediction.txt",quote=FALSE,col.names=T,row.names=F,sep='\t')
  ####################################################################################
  return(Logit_roc)
}

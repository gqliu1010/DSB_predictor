// ConsoleApplication1.cpp : �������̨Ӧ�ó������ڵ㡣
//



#include "string.h"
#include "math.h"
#include"stdio.h"
#include "stdlib.h"
#include"ctype.h"
#include"conio.h"



int main()
{
	FILE*fp1, *fp2, *fout[20];
	long int i, j, k, l, m, n, p, N1,N2, t = 0, num=0, count = 0;
	char str[50001], head[100], step[10], enter[] = "\n", ww[100];
	double lichangshu[16][12];
	long int oner[4], twoer[4][4], length, window1 = 10000, window2 = 11, half;
	double gc, sum1, sum2;
	double sum[12], G[12];
	char ch[4] = { 'A', 'T', 'G', 'C' };
	char filename1[1000], filename2[] = "positive_liu_", filename3[100], filename4[] = ".txt";



	if ((fp1 = fopen("physical descriptors of complex.txt", "r")) == NULL)
	{
		printf("cannot open this file1 \n");
		exit(0);
	}



	if ((fp2 = fopen("D:\\�ṹ����ѧ\\DSB GC and information\\DSB_positive_1000bp.fa", "r")) == NULL)
	{
		printf("cannot open fp1 \n");
		exit(0);
	}
	


	for (i = 0; i < 12; i++)
	{

		for (j = 0; j < 100; j++)
		{
			filename1[j] = '\0';
		}

		_itoa(i + 1, filename3, 10);
		strcpy(filename1, filename2);
		strcat(filename1, filename3);
		strcat(filename1, filename4);


		if ((fout[i] = fopen(filename1, "w+")) == NULL)
		{
			printf("cannot open this file \n");
			exit(0);
		}
	}




	for (m = 0; m< 12+1; m++)
	{
		fscanf(fp1, "%s\t", &head);
		
	}


	for (m = 0; m< 16; m++)               ///     'm�����������������
	{
		fscanf(fp1, "%s\t", &step);
		for (n = 0; n< 12; n++)            ///     'n�����������������
		{
			fscanf(fp1, "%lf\t", &lichangshu[m][n]);
			printf("%lf\t", lichangshu[m][n]);
		}
		printf("\n");
	}





	half = window2 / 2+1 ;
	printf("half=%ld\n", half);

   /* 
	for (i = 0; i<(window2-1) / 2; i++)
	{
		fprintf(fp3, "NAN\n");
	}
	*/ 


	count = 0;

	while (!feof(fp2))
	{
		memset(str, '\0', window2);
		fgets(str, window2 + 1, fp2);


		if (str[0] == '@')
			break;



		if (str[0] == '>')
		{
			if (strstr(str,"\n")==NULL)
			fgets(ww, 100, fp2);
			
			
			count++;
			num=0;
			//for (i = 0; i < 12; i++)
				//fprintf(fout[i],"seq%d",count);
				
			printf("%s\n", str);

			continue;
		}
		
		num++;
		
		
				
		length = strlen(str);
		
		
		
		if(length==0)
			break;
			
			
			
		///if (str[window - 1] == '\n')
		if(strstr(str,enter)!=NULL)
		{
			for (i = 0; i < 12; i++)
				fprintf(fout[i],"\n");
			continue;
		}


		if (length == window2)
			fseek(fp2, -(window2 - 1), 1);///Ϊȫ�������޼��ɨ���������///


		///////////////////////////////////������ͳ�Ƽ������////////////////////				
		sum1 = 0;
		for (i = 0; i<4; i++)
			oner[i] = 0;


		for (l = 0; l<window2; l++)
		{
			if (str[l] == '\n')
				break;
			for (j = 0; j<4; j++)
			if (str[l] == ch[j])
				oner[j] = oner[j] + 1;
		}


		for (i = 0; i<4; i++)
			sum1 = sum1 + oner[i];

		gc = (oner[2] + oner[3]) / sum1;


		//f1[0]=f1[1]=(oner[0]+oner[1])*0.5;
		//f1[2]=f1[3]=(oner[2]+oner[3])*0.5;




		////////////////////////////////////ͳ��2-mer///////////////////////////

		sum2 = 0; 
	



		for (i = 0; i<4; i++)
		{
			for (j = 0; j<4; j++)
				twoer[i][j] = 0;
		}


		for (n = 0; n < 12; n++)
			sum[n] = 0;

		

		for (l = 0; l<window2; l++)
		{
			if (str[l] == '\n')
			{
				///fprintf(fp4,"here:%c=%ld",str[l],l);////����Ƿ����쳣����///
				break;
			}

			for (j = 0; j < 4; j++)
			{
				if (str[l] == ch[j])
				{
					for (k = 0; k < 4; k++)
					{
						if (str[l + 1] == ch[k])
						{

							twoer[j][k]++;

							N1 = 4 * (j)+(k);////������������
						
							for (n = 0; n < 12; n++)
							sum[n] = sum[n] + lichangshu[N1][n];

						}
					}
				}
			}
		}



		for (i = 0; i<4; i++)
		{
			for (j = 0; j<4; j++)
				sum2 = sum2 + twoer[i][j];
		}


		for (n = 0; n < 12; n++)
		{
			G[n] = sum[n] / sum2;
		}

		//printf("%f\n", G[2]);
		/////////////////////////////////////////////////////////////////////////////////////////



		for (n = 0; n < 12; n++)
		{
			if(num==1)
				fprintf(fout[n],"%f", G[n]);
			else
				fprintf(fout[n], "\t%f", G[n]);
		}

	}


	_fcloseall;

}


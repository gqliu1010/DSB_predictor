install.packages('devtools')
library(devtools)
install_github(repo = "TsuPeiChiu/DNAshapeR", unload = TRUE) 

gh_suggest(TsuPeiChiu/DNAshapeR)
install.packages("TTR")
library(TTR)
library(DNAshapeR)

shapeType=c("MGW","EP","HelT","Rise","Roll","Shift","Slide","Tilt","Buckle", "Opening", "ProT", "Shear", "Stagger", "Stretch")

pred1=getShape("D:/DSB_nochrY/DSB_original documents_nochrY/DSB_negative_1000bp.fa",shapeType=shapeType)
data1=as.data.frame(pred1$MGW)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T) 


pred2=getShape("D:/DSB_nochrY/DSB_original documents_nochrY/DSB_positive_1000bp.fa",shapeType=shapeType)
data2=as.data.frame(pred2$MGW)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)



aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor=c("blue","red")
write.table(data1,"negative_MGW.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"positive_MGW.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_MGW.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_MGW.jpeg",width=600*6,height=400*6,res=72*8) 
par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))
#mgp中第一个数字控制label的位置，第二个控制刻度值的位置，第三个控制轴的位置
matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="MGW")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
#######
data1=as.data.frame(pred1$EP)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)
data2=as.data.frame(pred2$EP)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor=c ("blue","red")

write.table(data1,"neg_EP.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_EP.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_EP.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_EP.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))



matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="EP")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
#######
#######
data1=as.data.frame(pred1$HelT)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)
data2=as.data.frame(pred2$HelT)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)
aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_HelT.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_HelT.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_HelT.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_HelT.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="HelT")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()

########
########
########


data1=as.data.frame(pred1$Rise)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)


data2=as.data.frame(pred2$Rise)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Rise.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Rise.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Rise.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Rise.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Rise")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
########
########
########
########
data1=as.data.frame(pred1$Roll)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Roll)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")


write.table(data1,"neg_Roll.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Roll.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Roll.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Roll.jpeg",width=600*6,height=400*6,res=72*8)


par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Roll")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()

########
########
########
########
########
data1=as.data.frame(pred1$Shift)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Shift)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")
write.table(data1,"neg_Shift.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Shift.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Shift.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Shift.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Shift")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
#########
#########
#########
#########
#########
#########
data1=as.data.frame(pred1$Slide)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)


data2=as.data.frame(pred2$Slide)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Slide.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Slide.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Slide.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Slide.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Slide")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()

#########
data1=as.data.frame(pred1$Tilt)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Tilt)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Tilt.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Tilt.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Tilt.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Tilt.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))
matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Tilt")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
#############
#############
data1=as.data.frame(pred1$Buckle)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Buckle)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Buckle.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Buckle.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Buckle.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Buckle.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Buckle")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
###########
data1=as.data.frame(pred1$Opening)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Opening)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Opening.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Opening.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Opening.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Opening.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Opening")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()

##########
data1=as.data.frame(pred1$ProT)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$ProT)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len<-nrow(mat)
pos<-seq(-len/2,len/2-1,by=1)
colnames(mat)<-c("negative","positive")
mycolor<- c("blue","red")

write.table(data1,"neg_ProT.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_ProT.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_ProT.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_ProT.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))
matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="ProT")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()

##############
data1=as.data.frame(pred1$Shear)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Shear)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Shear.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Shear.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Shear.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Shear.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Shear")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
###############
data1=as.data.frame(pred1$Stagger)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Stagger)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)
aver1<-SMA(aver1,10)
aver2<-SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")

write.table(data1,"neg_Stagger.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Stagger.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Stagger.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Stagger.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))

matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Stagger")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()
##############


data1=as.data.frame(pred1$Stretch)
data1=data1[,6:(ncol(data1)-3)]
aver1=apply(data1,2,mean,na.rm=T)

data2=as.data.frame(pred2$Stretch)
data2=data2[,6:(ncol(data2)-3)]
aver2=apply(data2,2,mean,na.rm=T)

aver1=SMA(aver1,10)
aver2=SMA(aver2,10)

mat=as.data.frame(aver1)
mat=cbind(mat,aver2)

len=nrow(mat)
pos=seq(-len/2,len/2-1,by=1)
colnames(mat)=c("negative","positive")
mycolor= c("blue","red")


write.table(data1,"neg_Stretch.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(data2,"pos_Stretch.txt",quote=F,row.names = F,col.names = F,sep='\t')
write.table(mat,"aver_Stretch.txt",quote=F,row.names = F,col.names = F,sep='\t')
jpeg("aver_Stretch.jpeg",width=600*6,height=400*6,res=72*8)

par(cex=1.3)
par(mar=c(4,4,2,4))
par(mgp = c(2, 0.5, 0))


matplot(pos,mat,type="l",lty=1,lwd = 2,cex=0,xlim=c(-len/2,len/2),col=mycolor,xlab="Position relative to seq center (bp)",ylab="Stretch")
legend("bottomright",bty='n',colnames(mat),col=mycolor,text.col=mycolor,lty=1,lwd = 2,xpd=T,horiz=F)
abline(v=0,lty=2,lwd=1,col="black")
dev.off()

